package com.infor.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class MemoryUsageXMLTest {
	
	SearchReplaceXML srx;
	String inputFile=System.getProperty("user.dir")+"\\tests\\input.xml";
	String resultFile=System.getProperty("user.dir")+"\\tests\\result.xml";
	String expectedFile=System.getProperty("user.dir")+"\\tests\\expected.xml";
	
	@BeforeEach
	void setUp() throws Exception {
		srx=new SearchReplaceXML("trace","error");
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	/**
	 * Tests if the expected generated file (result) is identical to
	 * the expected one (created manually an put in the Current user 
	 * directory under folder "tests".
	 * This approach allows to test content and format.
	 * It tests also the memory usage.
	 * @throws IOException
	 */
	@org.junit.jupiter.api.Test
	void testSearchReplaceXML() throws IOException {
		
	    Runtime runtime = Runtime.getRuntime();
	    long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
	    
	    srx.searchReplaceXML(inputFile, resultFile);
		assertEquals(FileUtils.readFileToString(new File(expectedFile),"UTF-8"), 
			    FileUtils.readFileToString(new File(resultFile),"UTF-8"));
		
		long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
		long usedMemory=(usedMemoryAfter-usedMemoryBefore)/1048576;
	    assertTrue("This program consumes "+usedMemory+" of memory.", 100 > usedMemory);
		System.out.println("Memory usage in Megabytes:" + usedMemory);

	}

}
