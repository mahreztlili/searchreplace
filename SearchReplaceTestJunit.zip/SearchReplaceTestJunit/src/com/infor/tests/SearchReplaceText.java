/*
 * Copyright (c) 2021 All rights reserved.
 * Just for test.
 */
/**
 * Unit Test;
 * This class is used to search and replace text phrases in 
 * a text file.
 * @author  Mahrez TLILI
 * @date    25/10/2021
 */

package com.infor.tests;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import org.apache.log4j.Logger;

public class SearchReplaceText {

	/**Using log4j to print errors*/
	private Logger log = Logger.getLogger(SearchReplaceText.class.getName());

	
	/**
	 * For Unit Tests,
	 * this method reads the text file (from the standard input) line by
	 * line using scanner Object (see javadoc), searches for a specific 
	 * text  (searchText)  in the current line and replaces it, if found,
	 * with replaceText.
	 * @throws IOException 
	 * 
	 */ 
	public void searchReplaceTXT(String searchText, String replaceText,FileInputStream inputFile,FileOutputStream outputStream) throws IOException  {
		Scanner scan = null;
		String line=null;
		
		try {
			scan = new Scanner(inputFile);

			while(scan.hasNextLine()){
				
				line=scan.nextLine();
				
				if (line.contains(searchText)) {
					line=line.replace(searchText,replaceText);
				}
				line+="\r\n";
				byte[] strToBytes = line.getBytes();
			    outputStream.write(strToBytes);
				
			}
			
		}
		catch(Exception e) {
			log.error("",e);
		}
		finally {
			if(scan !=null) 
				scan.close();
		}

	}
	
}
