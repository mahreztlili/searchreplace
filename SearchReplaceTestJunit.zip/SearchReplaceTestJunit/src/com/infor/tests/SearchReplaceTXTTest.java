package com.infor.tests;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class SearchReplaceTXTTest {
	
	
	SearchReplaceText srTxt;
	FileInputStream inputFile;
	FileOutputStream outputStream;

    /**
     *  executed before every test. creates I/O streams 
     *  */
	@BeforeEach
    public void setUp()  throws IOException {
		inputFile = new FileInputStream(System.getProperty("user.dir")+"\\tests\\input.txt");
		outputStream = new FileOutputStream(System.getProperty("user.dir")+"\\tests\\result.txt");
	    srTxt=new SearchReplaceText();	
    }

	/**
	 * Tests if the expected generated file (result) is identical to
	 * the expected one (created manually an put in the Current user 
	 * directory under folder "tests".
	 * @throws IOException
	 */
	@org.junit.jupiter.api.Test
	void testSearchReplaceTXT() throws IOException{
		
		srTxt.searchReplaceTXT("customer", "client",inputFile,outputStream);
		assertEquals(FileUtils.readFileToString(new File(System.getProperty("user.dir")+"\\tests\\expected.txt"),"UTF-8"), 
			    FileUtils.readFileToString(new File(System.getProperty("user.dir")+"\\tests\\result.txt"),"UTF-8"));

	}
    
	/**
	 * Closing opened resources.
	 * */
	@AfterEach
	public void tearDown() throws IOException {
		if(outputStream!=null) 
			outputStream.close();
		if(inputFile!=null)
			inputFile.close();
	}
}
