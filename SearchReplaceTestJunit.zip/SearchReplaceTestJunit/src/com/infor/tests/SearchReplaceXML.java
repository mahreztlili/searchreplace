/*
 * Copyright (c) 2021 All rights reserved.
 * Just for unit test.
 */
/**
 * This class is used to search and replace text phrases in 
 * a xml file using SAXParser.
 * @author  Mahrez TLILI
 * @date    22/10/2021
 */

package com.infor.tests;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.Attributes2;
import org.xml.sax.ext.Attributes2Impl;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLFilterImpl;

public class SearchReplaceXML extends DefaultHandler{
	
	/**
	 * @param searchText: Text to search in the file
	 * @param replaceText: will replace search Text
	 */
	private String searchText;
	private String replaceText;
	
	/**Using log4j to print errors*/
	private Logger log = Logger.getLogger(SearchReplaceXML.class.getName()); 
	
	/**
	 * Constructor to initialize attributes.
	 */
	public SearchReplaceXML(String searchText, String replaceText) {
		
		this.searchText=searchText;
		this.replaceText=replaceText;
		
	}
	/**
	 * this method parse an xml file (from the standard input) 
	 * using SAXParser, searches for a specific text
	 * (searchText)  in the attribute's value and replaces it, if found,
	 * with replaceText.
	 */ 
	public void searchReplaceXML(String inputFile,String resultFile){

		
		try {
        // create a SAXParser	
		SAXParserFactory parserFactory = SAXParserFactory.newInstance();
		SAXParser parser = parserFactory.newSAXParser();
		/* create a XMLReader from SAXParser */
		XMLReader reader = parser.getXMLReader();
        //use XMLFilterImpl to read xml file and replace attributes' values.
		XMLReader xr = new XMLFilterImpl(reader) {
			/* @throws SAXException
			 * @Override startElement() of SAXParser Object
			 * the method filter a start element event.
			 * Read attributes's values, searches for a specific string then,
			 * if found, creates an Attribute with the new value, and add it to the Attributes 
			 * Array. 
			 *  */
			@Override
			public void startElement(String uri, String localName, String qName, Attributes atts) {
				Attributes2 attrs = (Attributes2) atts;
				String value,qName1,type;
				Attributes2Impl newAttrs = new Attributes2Impl();
				for (int i = 0; i < attrs.getLength(); i++) {
					value= attrs.getValue(i);
					qName1 = attrs.getQName(i);
					type = attrs.getType(i);
					if (value.contains(searchText)) {

						value=value.replace(searchText, replaceText);
						newAttrs.addAttribute(null, null, qName1, type, value);
					}
					else {
						newAttrs.addAttribute(null, null, qName1, type, value);
					}
				}

				try {
					super.startElement(uri, localName, qName, newAttrs);
				} catch (SAXException e) {
					log.error(e);
					
				}

			}
		
		};
		//Transform the input xml file after the modification.
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "no");
		Source src = new SAXSource(xr, new InputSource(inputFile));
		StreamResult res = new StreamResult(resultFile);
		transformer.transform(src, res);
		}
		catch(Exception e) {
			log.error(e);
		}
		
	}

}
