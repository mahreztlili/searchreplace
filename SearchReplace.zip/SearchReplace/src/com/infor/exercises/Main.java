package com.infor.exercises;

public class Main {

	/**Using class Loggor to print errors */
	private static Loggor log = new Loggor(Main.class.getName()); 

	public static void main(String[] args) {

		/** Check user inputs*/
		if( args.length!=3) {
			System.err.println("This program requires 3 parameters: file type(txt, xml), searchText, replaceText."); 
			System.exit(0); 
		}
		String fileType = args[0].toLowerCase();
		String textToFind = args[1];
		String textToReplace = args[2];

		if( !fileType.equals("txt") && !fileType.equals("xml")) {
			System.err.println("First argument must be\"txt\" or \"xml\".");
			System.exit(0); 
		}

		try {
			switch (fileType) {
			case "txt":
				SearchReplaceText searchReplaceText=new SearchReplaceText();
				searchReplaceText.searchReplaceTXT(textToFind, textToReplace);
				break;

			case "xml":
				SearchReplaceXML searchReplaceXML=new SearchReplaceXML(textToFind, textToReplace);
				searchReplaceXML.searchReplaceXML();
				break;
			}
		}
		catch(Exception e) {
			log.printLog(e);
		}



	}

}
