package com.infor.exercises;

import org.apache.log4j.Logger;

public class Loggor {
	
	
	private Logger log;
	public Loggor(String className){
		/**Using log4j to print errors*/
		log= Logger.getLogger(className);
	}
	
	public void printLog(Exception e) {
		log.error("Error: ",e);//write the error to the log file
		System.err.println("Error: "+e.getMessage()+"\n-- See log file for more details. --");//print error the user
	}
	


}
