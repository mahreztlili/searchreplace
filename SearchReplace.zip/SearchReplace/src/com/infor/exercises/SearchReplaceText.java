/*
 * Copyright (c) 2021 All rights reserved.
 * Just for test.
 */
/**
 * This class is used to search and replace text phrases in 
 * a text file.
 * @author  Mahrez TLILI
 * @date    21/10/2021
 */

package com.infor.exercises;

import java.util.Scanner;

public class SearchReplaceText {

	/**Using class Loggor to print errors */
	private static Loggor log = new Loggor(Main.class.getName()); 


	/**
	 * this method reads the text file (from the standard input) line by
	 * line using scanner Object (see javadoc), searches for a specific 
	 * text  (searchText)  in the current line and replaces it, if found,
	 * with replaceText.
	 * In both cases (text found or not), it prints the line
	 * to standard output to be written directly to an output
	 * file.
	 * 
	 */ 
	public void searchReplaceTXT(String searchText, String replaceText)  {

		Scanner scan = null;
		String line=null;
		try {
			scan = new Scanner(System.in);

			while(scan.hasNextLine()){
				line=scan.nextLine();
				if (line.contains(searchText)) {
					line=line.replace(searchText,replaceText);
				}
				System.out.println(line);
			}

		}
		catch(Exception e) {
			log.printLog(e);
			
		}
		finally {
			if(scan !=null) 
				scan.close();
		}

	}
}
